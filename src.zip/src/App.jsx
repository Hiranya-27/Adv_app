import { RouterProvider, createBrowserRouter } from "react-router-dom"
// import CustomNavbar from "./components/CustomNavbar"
// import CustomSidebar from "./components/CustomSidebar"
import Home from "./pages/Home"
// import About from "./pages/About"
// import Contact from "./pages/Contact"
import { Suspense, lazy } from "react"
import Spinner from "./components/Spinner";
const LazyAbout =lazy(()=>import("./pages/About"));
const LazyContact =lazy(()=>import("./pages/Contact"));
const App =()=>{
  const router=createBrowserRouter([
    {
      path:'/home',
      element:<Suspense fallback={<Spinner/>}> <Home/></Suspense>
    },
    {
      path:'/about',
      element:<Suspense fallback={<Spinner/>}><LazyAbout/></Suspense>
    },
    {
      path:'/contact',
      element :<Suspense fallback={<Spinner/>}><LazyContact/></Suspense>
    }
  ])
   return (
      <RouterProvider router={router}/>
  )
}

export default App
