import { Loader } from "rsuite"

const Spinner=()=>{
    return(
        <>
        <Loader/>
        </>
    )
}
export default Spinner