import CustomNavbar from "../components/CustomNavbar"

const Contact=()=>{
    return(
        <div><CustomNavbar/></div>
    )
}
export default Contact