import CustomNavbar from "../components/CustomNavbar"

const Home=()=>{
    return(
      <div>
        <header>
            <CustomNavbar/>
        </header>
        <main>
            <section className="hero">
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, hic laborum corrupti consequuntur repellat, minima voluptas sit neque, dolore enim architecto aliquam! Non optio minima quas tenetur cupiditate, dolore delectus.
            </section>
        </main>
      </div>
    )
}
export default Home